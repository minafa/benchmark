#define CLASS 'D'
#define NUM_PROCS 2048
/*
   This file is generated automatically by the setparams utility.
   It sets the number of processors and the class of the NPB
   in this directory. Do not modify it by hand.   */
   
#define COMPILETIME "23 Oct 2015"
#define NPBVERSION "3.3"
#define MPICC "mpicc -mcmodel=medium"
#define CFLAGS "-O3"
#define CLINK "$(MPICC)"
#define CLINKFLAGS "-O3"
#define CMPI_LIB "-L/cluster/software/VERSIONS/openmpi.intel-..."
#define CMPI_INC "-I/cluster/software/VERSIONS/openmpi.intel-..."
